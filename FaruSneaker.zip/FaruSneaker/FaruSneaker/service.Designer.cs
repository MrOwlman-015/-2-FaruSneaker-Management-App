﻿namespace FaruSneaker
{
    partial class service
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.cButton6 = new FaruSneaker.CButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cButton5 = new FaruSneaker.CButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cButton4 = new FaruSneaker.CButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cButton3 = new FaruSneaker.CButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cButton2 = new FaruSneaker.CButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cButton1 = new FaruSneaker.CButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Price = new System.Windows.Forms.TextBox();
            this.rtx_Description = new System.Windows.Forms.RichTextBox();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.txt_ID = new System.Windows.Forms.TextBox();
            this.dgv_service = new System.Windows.Forms.DataGridView();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.lbl_Description = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_service)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(194)))), ((int)(((byte)(57)))));
            this.splitContainer1.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox2);
            this.splitContainer1.Panel1.Controls.Add(this.panel6);
            this.splitContainer1.Panel1.Controls.Add(this.panel5);
            this.splitContainer1.Panel1.Controls.Add(this.panel4);
            this.splitContainer1.Panel1.Controls.Add(this.panel3);
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel8);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Size = new System.Drawing.Size(1358, 656);
            this.splitContainer1.SplitterDistance = 189;
            this.splitContainer1.TabIndex = 2;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::FaruSneaker.Properties.Resources.logo;
            this.pictureBox2.Location = new System.Drawing.Point(3, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(189, 164);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.Controls.Add(this.cButton6);
            this.panel6.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel6.Location = new System.Drawing.Point(6, 476);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(186, 58);
            this.panel6.TabIndex = 7;
            // 
            // cButton6
            // 
            this.cButton6.BackColor = System.Drawing.Color.Transparent;
            this.cButton6.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton6.BorderColor = System.Drawing.Color.Transparent;
            this.cButton6.BorderRadius = 0;
            this.cButton6.BorderSize = 0;
            this.cButton6.CausesValidation = false;
            this.cButton6.FlatAppearance.BorderSize = 0;
            this.cButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton6.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton6.ForeColor = System.Drawing.Color.Black;
            this.cButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton6.Location = new System.Drawing.Point(3, 9);
            this.cButton6.Name = "cButton6";
            this.cButton6.Size = new System.Drawing.Size(180, 41);
            this.cButton6.TabIndex = 1;
            this.cButton6.TabStop = false;
            this.cButton6.Text = "Thanh toán";
            this.cButton6.TextColor = System.Drawing.Color.Black;
            this.cButton6.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.cButton5);
            this.panel5.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel5.Location = new System.Drawing.Point(6, 415);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(186, 58);
            this.panel5.TabIndex = 6;
            // 
            // cButton5
            // 
            this.cButton5.BackColor = System.Drawing.Color.Transparent;
            this.cButton5.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton5.BorderColor = System.Drawing.Color.Transparent;
            this.cButton5.BorderRadius = 0;
            this.cButton5.BorderSize = 0;
            this.cButton5.CausesValidation = false;
            this.cButton5.FlatAppearance.BorderSize = 0;
            this.cButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton5.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton5.ForeColor = System.Drawing.Color.Black;
            this.cButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton5.Location = new System.Drawing.Point(3, 9);
            this.cButton5.Name = "cButton5";
            this.cButton5.Size = new System.Drawing.Size(180, 41);
            this.cButton5.TabIndex = 1;
            this.cButton5.TabStop = false;
            this.cButton5.Text = "Nhân viên";
            this.cButton5.TextColor = System.Drawing.Color.Black;
            this.cButton5.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.cButton4);
            this.panel4.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel4.Location = new System.Drawing.Point(6, 354);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(186, 58);
            this.panel4.TabIndex = 5;
            // 
            // cButton4
            // 
            this.cButton4.BackColor = System.Drawing.Color.Transparent;
            this.cButton4.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton4.BorderColor = System.Drawing.Color.Transparent;
            this.cButton4.BorderRadius = 0;
            this.cButton4.BorderSize = 0;
            this.cButton4.CausesValidation = false;
            this.cButton4.FlatAppearance.BorderSize = 0;
            this.cButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton4.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton4.ForeColor = System.Drawing.Color.Black;
            this.cButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton4.Location = new System.Drawing.Point(3, 9);
            this.cButton4.Name = "cButton4";
            this.cButton4.Size = new System.Drawing.Size(180, 41);
            this.cButton4.TabIndex = 1;
            this.cButton4.TabStop = false;
            this.cButton4.Text = "  Khách hàng";
            this.cButton4.TextColor = System.Drawing.Color.Black;
            this.cButton4.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.cButton3);
            this.panel3.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel3.Location = new System.Drawing.Point(3, 293);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(186, 58);
            this.panel3.TabIndex = 4;
            // 
            // cButton3
            // 
            this.cButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(234)))), ((int)(((byte)(236)))));
            this.cButton3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(234)))), ((int)(((byte)(236)))));
            this.cButton3.BorderColor = System.Drawing.Color.Transparent;
            this.cButton3.BorderRadius = 0;
            this.cButton3.BorderSize = 0;
            this.cButton3.CausesValidation = false;
            this.cButton3.FlatAppearance.BorderSize = 0;
            this.cButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton3.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton3.ForeColor = System.Drawing.Color.Black;
            this.cButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton3.Location = new System.Drawing.Point(2, 9);
            this.cButton3.Name = "cButton3";
            this.cButton3.Size = new System.Drawing.Size(183, 41);
            this.cButton3.TabIndex = 1;
            this.cButton3.TabStop = false;
            this.cButton3.Text = "Sản phẩm";
            this.cButton3.TextColor = System.Drawing.Color.Black;
            this.cButton3.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.cButton2);
            this.panel2.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel2.Location = new System.Drawing.Point(3, 232);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 58);
            this.panel2.TabIndex = 3;
            // 
            // cButton2
            // 
            this.cButton2.BackColor = System.Drawing.Color.Transparent;
            this.cButton2.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton2.BorderColor = System.Drawing.Color.Transparent;
            this.cButton2.BorderRadius = 0;
            this.cButton2.BorderSize = 0;
            this.cButton2.CausesValidation = false;
            this.cButton2.FlatAppearance.BorderSize = 0;
            this.cButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton2.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton2.ForeColor = System.Drawing.Color.Black;
            this.cButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton2.Location = new System.Drawing.Point(2, 9);
            this.cButton2.Name = "cButton2";
            this.cButton2.Size = new System.Drawing.Size(183, 41);
            this.cButton2.TabIndex = 1;
            this.cButton2.TabStop = false;
            this.cButton2.Text = "Tài khoản";
            this.cButton2.TextColor = System.Drawing.Color.Black;
            this.cButton2.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.cButton1);
            this.panel1.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel1.Location = new System.Drawing.Point(3, 171);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(186, 58);
            this.panel1.TabIndex = 2;
            // 
            // cButton1
            // 
            this.cButton1.BackColor = System.Drawing.Color.Transparent;
            this.cButton1.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton1.BorderColor = System.Drawing.Color.Transparent;
            this.cButton1.BorderRadius = 0;
            this.cButton1.BorderSize = 0;
            this.cButton1.CausesValidation = false;
            this.cButton1.FlatAppearance.BorderSize = 0;
            this.cButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton1.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton1.ForeColor = System.Drawing.Color.Black;
            this.cButton1.Image = global::FaruSneaker.Properties.Resources.homeicons;
            this.cButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton1.Location = new System.Drawing.Point(2, 9);
            this.cButton1.Name = "cButton1";
            this.cButton1.Size = new System.Drawing.Size(183, 41);
            this.cButton1.TabIndex = 1;
            this.cButton1.TabStop = false;
            this.cButton1.Text = "Trang chủ";
            this.cButton1.TextColor = System.Drawing.Color.Black;
            this.cButton1.UseVisualStyleBackColor = false;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label1);
            this.panel8.Controls.Add(this.pictureBox1);
            this.panel8.Location = new System.Drawing.Point(5, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1175, 78);
            this.panel8.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1053, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Đăng xuất";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1178, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txt_Price);
            this.groupBox1.Controls.Add(this.rtx_Description);
            this.groupBox1.Controls.Add(this.txt_Name);
            this.groupBox1.Controls.Add(this.txt_ID);
            this.groupBox1.Controls.Add(this.dgv_service);
            this.groupBox1.Controls.Add(this.btn_Update);
            this.groupBox1.Controls.Add(this.btn_Remove);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.btn_Add);
            this.groupBox1.Controls.Add(this.btn_Clear);
            this.groupBox1.Controls.Add(this.lbl_ID);
            this.groupBox1.Controls.Add(this.lbl_Description);
            this.groupBox1.Controls.Add(this.lbl_Name);
            this.groupBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(26, 86);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1133, 575);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN DỊCH VỤ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(15, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 24);
            this.label2.TabIndex = 39;
            this.label2.Text = "Đơn giá";
            // 
            // txt_Price
            // 
            this.txt_Price.Location = new System.Drawing.Point(15, 146);
            this.txt_Price.Name = "txt_Price";
            this.txt_Price.Size = new System.Drawing.Size(234, 32);
            this.txt_Price.TabIndex = 38;
            // 
            // rtx_Description
            // 
            this.rtx_Description.Location = new System.Drawing.Point(15, 222);
            this.rtx_Description.Name = "rtx_Description";
            this.rtx_Description.Size = new System.Drawing.Size(505, 224);
            this.rtx_Description.TabIndex = 37;
            this.rtx_Description.Text = "";
            // 
            // txt_Name
            // 
            this.txt_Name.Location = new System.Drawing.Point(286, 69);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(234, 32);
            this.txt_Name.TabIndex = 35;
            // 
            // txt_ID
            // 
            this.txt_ID.Location = new System.Drawing.Point(15, 68);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.Size = new System.Drawing.Size(234, 32);
            this.txt_ID.TabIndex = 34;
            // 
            // dgv_service
            // 
            this.dgv_service.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_service.Location = new System.Drawing.Point(546, 69);
            this.dgv_service.Name = "dgv_service";
            this.dgv_service.RowHeadersWidth = 51;
            this.dgv_service.RowTemplate.Height = 29;
            this.dgv_service.Size = new System.Drawing.Size(564, 458);
            this.dgv_service.TabIndex = 33;
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.btn_Update.ForeColor = System.Drawing.Color.Black;
            this.btn_Update.Location = new System.Drawing.Point(387, 490);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(133, 37);
            this.btn_Update.TabIndex = 32;
            this.btn_Update.Text = "Cập nhật ";
            this.btn_Update.UseVisualStyleBackColor = false;
            // 
            // btn_Remove
            // 
            this.btn_Remove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.btn_Remove.ForeColor = System.Drawing.Color.Black;
            this.btn_Remove.Location = new System.Drawing.Point(202, 490);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(133, 37);
            this.btn_Remove.TabIndex = 31;
            this.btn_Remove.Text = "Xóa ";
            this.btn_Remove.UseVisualStyleBackColor = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(780, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 24);
            this.label11.TabIndex = 30;
            this.label11.Text = "THEO DÕI DỊCH VỤ";
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.btn_Add.ForeColor = System.Drawing.Color.Black;
            this.btn_Add.Location = new System.Drawing.Point(15, 490);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(133, 37);
            this.btn_Add.TabIndex = 28;
            this.btn_Add.Text = "Thêm";
            this.btn_Add.UseVisualStyleBackColor = false;
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btn_Clear.ForeColor = System.Drawing.Color.Black;
            this.btn_Clear.Location = new System.Drawing.Point(387, 452);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(133, 32);
            this.btn_Clear.TabIndex = 27;
            this.btn_Clear.Text = "Xóa tùy chọn";
            this.btn_Clear.UseVisualStyleBackColor = false;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_ID.Location = new System.Drawing.Point(15, 41);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(81, 24);
            this.lbl_ID.TabIndex = 9;
            this.lbl_ID.Text = "Mã dịch vụ";
            // 
            // lbl_Description
            // 
            this.lbl_Description.AutoSize = true;
            this.lbl_Description.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Description.Location = new System.Drawing.Point(15, 195);
            this.lbl_Description.Name = "lbl_Description";
            this.lbl_Description.Size = new System.Drawing.Size(46, 24);
            this.lbl_Description.TabIndex = 13;
            this.lbl_Description.Text = "Mô tả";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_Name.Location = new System.Drawing.Point(286, 41);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(84, 24);
            this.lbl_Name.TabIndex = 11;
            this.lbl_Name.Text = "Tên dịch vụ";
            // 
            // service
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 656);
            this.Controls.Add(this.splitContainer1);
            this.Name = "service";
            this.Text = "service";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_service)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private SplitContainer splitContainer1;
        private PictureBox pictureBox2;
        private Panel panel6;
        private CButton cButton6;
        private Panel panel5;
        private CButton cButton5;
        private Panel panel4;
        private CButton cButton4;
        private Panel panel3;
        private CButton cButton3;
        private Panel panel2;
        private CButton cButton2;
        private Panel panel1;
        private CButton cButton1;
        private Panel panel8;
        private Label label1;
        private PictureBox pictureBox1;
        private GroupBox groupBox1;
        private RichTextBox rtx_Description;
        private TextBox txt_Name;
        private TextBox txt_ID;
        private DataGridView dgv_service;
        private Button btn_Update;
        private Button btn_Remove;
        private Label label11;
        private Button btn_Add;
        private Button btn_Clear;
        private Label lbl_ID;
        private Label lbl_Description;
        private Label lbl_Name;
        private Label label2;
        private TextBox txt_Price;
    }
}