﻿namespace FaruSneaker
{
    partial class customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            panel6 = new Panel();
            panel5 = new Panel();
            panel4 = new Panel();
            panel3 = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            groupBox1 = new GroupBox();
            txt_type = new TextBox();
            txt_cphone = new TextBox();
            txt_cname = new TextBox();
            txt_cid = new TextBox();
            button3 = new Button();
            button1 = new Button();
            label5 = new Label();
            label3 = new Label();
            table_C = new DataGridView();
            label11 = new Label();
            button2 = new Button();
            label2 = new Label();
            label4 = new Label();
            panel8 = new Panel();
            txt_name = new TextBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            panel6.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)table_C).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.FromArgb(223, 194, 57);
            splitContainer1.Panel1.Controls.Add(panel6);
            splitContainer1.Panel1.Controls.Add(panel5);
            splitContainer1.Panel1.Controls.Add(panel4);
            splitContainer1.Panel1.Controls.Add(panel3);
            splitContainer1.Panel1.Controls.Add(panel2);
            splitContainer1.Panel1.Controls.Add(panel1);
            splitContainer1.Panel1.Controls.Add(pictureBox2);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(groupBox1);
            splitContainer1.Panel2.Controls.Add(panel8);
            splitContainer1.Size = new Size(1376, 703);
            splitContainer1.SplitterDistance = 193;
            splitContainer1.TabIndex = 0;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Transparent;
            panel6.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel6.Location = new Point(4, 475);
            panel6.Name = "panel6";
            panel6.Size = new Size(186, 58);
            panel6.TabIndex = 8;
            // 
            // cButton6
            // 
;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel5.Location = new Point(4, 414);
            panel5.Name = "panel5";
            panel5.Size = new Size(186, 58);
            panel5.TabIndex = 7;
            // 
            // cButton5
            // 

            // 
            // panel4
            // 
            panel4.BackColor = Color.Transparent;
            panel4.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel4.Location = new Point(4, 353);
            panel4.Name = "panel4";
            panel4.Size = new Size(186, 58);
            panel4.TabIndex = 6;
            // 
            // cButton4
            // 
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel3.Location = new Point(4, 292);
            panel3.Name = "panel3";
            panel3.Size = new Size(186, 58);
            panel3.TabIndex = 5;
            // 
            // cButton3
            // 

            // 
            // panel2
            // 
            panel2.BackColor = Color.Transparent;
            panel2.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel2.Location = new Point(4, 231);
            panel2.Name = "panel2";
            panel2.Size = new Size(186, 58);
            panel2.TabIndex = 4;
            // 
            // cButton2
            // 

            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel1.Location = new Point(4, 170);
            panel1.Name = "panel1";
            panel1.Size = new Size(186, 58);
            panel1.TabIndex = 3;
            // 
            // cButton1
            // 

            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.Image = Properties.Resources.logo;
            pictureBox2.Location = new Point(4, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(189, 164);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(txt_type);
            groupBox1.Controls.Add(txt_cphone);
            groupBox1.Controls.Add(txt_cname);
            groupBox1.Controls.Add(txt_cid);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(table_C);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label4);
            groupBox1.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(25, 81);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1133, 610);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "THÔNG TIN KHÁCH HÀNG";
            // 
            // txt_type
            // 
            txt_type.Location = new Point(872, 79);
            txt_type.Name = "txt_type";
            txt_type.Size = new Size(230, 32);
            txt_type.TabIndex = 47;
            // 
            // txt_cphone
            // 
            txt_cphone.Location = new Point(584, 79);
            txt_cphone.Name = "txt_cphone";
            txt_cphone.Size = new Size(230, 32);
            txt_cphone.TabIndex = 46;
            // 
            // txt_cname
            // 
            txt_cname.Location = new Point(309, 79);
            txt_cname.Name = "txt_cname";
            txt_cname.Size = new Size(230, 32);
            txt_cname.TabIndex = 45;
            // 
            // txt_cid
            // 
            txt_cid.Location = new Point(36, 79);
            txt_cid.Name = "txt_cid";
            txt_cid.Size = new Size(230, 32);
            txt_cid.TabIndex = 44;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(233, 197, 57);
            button3.ForeColor = Color.Black;
            button3.Location = new Point(679, 546);
            button3.Name = "button3";
            button3.Size = new Size(181, 37);
            button3.TabIndex = 43;
            button3.Text = "Xóa ";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(233, 197, 57);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(925, 546);
            button1.Name = "button1";
            button1.Size = new Size(181, 37);
            button1.TabIndex = 42;
            button1.Text = "Cập nhật";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(872, 42);
            label5.Name = "label5";
            label5.Size = new Size(72, 24);
            label5.TabIndex = 41;
            label5.Text = "Phân loại";
            label5.Click += label5_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(309, 42);
            label3.Name = "label3";
            label3.Size = new Size(131, 24);
            label3.TabIndex = 39;
            label3.Text = "Họ tên khách hàng";
            label3.Click += label3_Click;
            // 
            // table_C
            // 
            table_C.AllowUserToAddRows = false;
            table_C.AllowUserToDeleteRows = false;
            table_C.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            table_C.Location = new Point(36, 150);
            table_C.MultiSelect = false;
            table_C.Name = "table_C";
            table_C.ReadOnly = true;
            table_C.RowHeadersWidth = 51;
            table_C.RowTemplate.Height = 29;
            table_C.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            table_C.Size = new Size(1070, 390);
            table_C.TabIndex = 37;
            table_C.CellClick += table_C_CellClick;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.FlatStyle = FlatStyle.Popup;
            label11.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(498, 120);
            label11.Name = "label11";
            label11.Size = new Size(147, 24);
            label11.TabIndex = 30;
            label11.Text = "QUẢN LÝ KHÁCH HÀNG";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(233, 197, 57);
            button2.ForeColor = Color.Black;
            button2.Location = new Point(410, 546);
            button2.Name = "button2";
            button2.Size = new Size(181, 37);
            button2.TabIndex = 28;
            button2.Text = "Thêm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 42);
            label2.Name = "label2";
            label2.Size = new Size(109, 24);
            label2.TabIndex = 9;
            label2.Text = "Mã khách hàng";
            label2.Click += label2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(584, 42);
            label4.Name = "label4";
            label4.Size = new Size(96, 24);
            label4.TabIndex = 13;
            label4.Text = "Số điện thoại";
            label4.Click += label4_Click;
            // 
            // panel8
            // 
            panel8.Controls.Add(txt_name);
            panel8.Controls.Add(label1);
            panel8.Controls.Add(pictureBox1);
            panel8.Location = new Point(4, 0);
            panel8.Name = "panel8";
            panel8.Size = new Size(1175, 78);
            panel8.TabIndex = 1;
            // 
            // cButton7
            // 

            // 
            // txt_name
            // 
            txt_name.BackColor = Color.FromArgb(232, 232, 232);
            txt_name.Font = new Font("Bahnschrift Condensed", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            txt_name.Location = new Point(57, 20);
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(591, 40);
            txt_name.TabIndex = 48;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(48, 48, 48);
            label1.Font = new Font("Bahnschrift", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(1053, 25);
            label1.Name = "label1";
            label1.Size = new Size(101, 24);
            label1.TabIndex = 1;
            label1.Text = "Đăng xuất";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(48, 48, 48);
            pictureBox1.BorderStyle = BorderStyle.Fixed3D;
            pictureBox1.Location = new Point(-3, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1178, 75);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // customer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1376, 703);
            Controls.Add(splitContainer1);
            Name = "customer";
            Text = "customer";
            Load += customer_Load;
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)table_C).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel8;
        private Label label1;
        private PictureBox pictureBox1;
        private GroupBox groupBox1;
        private Label label11;
        private Button button2;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label label3;
        private DataGridView table_C;
        private Button button3;
        private Button button1;
        private TextBox txt_type;
        private TextBox txt_cphone;
        private TextBox txt_cname;
        private TextBox txt_cid;
        private TextBox txt_name;
    }
}